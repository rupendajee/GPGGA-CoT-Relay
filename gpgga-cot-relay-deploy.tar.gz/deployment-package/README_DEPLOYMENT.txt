GPGGA to CoT Relay - Deployment Instructions
===========================================

1. Edit the configuration:
   nano .env
   (Set your TAK_SERVER_URL)

2. Deploy the service:
   ./deploy.sh

3. Test the deployment:
   python3 test_gpgga_sender.py

4. View logs:
   docker-compose logs -f

5. Check metrics:
   curl http://localhost:8089/metrics
